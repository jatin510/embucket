import{e as t,j as e}from"./index-DGg_9BCt.js";import{I as r,a as c,b as o}from"./input-BA2zKS7w.js";import{b as i}from"./data-table-P8C6bW31.js";/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n=[["ellipse",{cx:"12",cy:"5",rx:"9",ry:"3",key:"msslwz"}],["path",{d:"M3 5V19A9 3 0 0 0 15 21.84",key:"14ibmq"}],["path",{d:"M21 5V8",key:"1marbg"}],["path",{d:"M21 12L18 17H22L19 22",key:"zafso"}],["path",{d:"M3 12A9 3 0 0 0 14.59 14.87",key:"1y4wr8"}]],p=t("database-zap",n),x=({title:s,children:a})=>e.jsxs("div",{className:"flex items-center justify-between border-b p-4",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("h1",{className:"text-xl font-semibold",children:s}),a]}),e.jsxs(r,{children:[e.jsx(c,{children:e.jsx(i,{})}),e.jsx(o,{className:"min-w-80",disabled:!0,placeholder:"Search"})]})]});export{p as D,x as P};
